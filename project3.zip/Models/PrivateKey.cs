﻿namespace Messenger.Models
{
    public class PrivateKey
    {
        public List<string> Email { get; set; }
        public string Key { get; set; }
    }
}
