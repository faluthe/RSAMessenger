﻿namespace Messenger.Models
{
    public class PublicKey
    {
        public string Email { get; set; }
        public string Key { get; set; }
    }
}
