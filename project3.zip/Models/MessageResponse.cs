﻿namespace Messenger.Models
{
    public class MessageResponse
    {
        public string Email { get; set; }
        public string Content { get; set; }
        public string MessageTime { get; set; }
    }
}
