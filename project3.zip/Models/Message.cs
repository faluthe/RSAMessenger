﻿namespace Messenger.Models
{
    public class Message
    {
        public string Email { get; set; }
        public string Content { get; set; }
    }
}
